// plugins/acme-research/business/service/acme-research.ts
async function createAcmeService(runtime) {
  return {
    actions: {
      "connection-status": async () => {
        const connections = await runtime.authorization.listConnections();
        const active = connections.find((connection) => connection.methodId === "api-key");
        const credential = await runtime.authorization.getCredential("api-key");
        return {
          connected: Boolean(credential),
          accountId: active?.accountId ?? null,
          methodId: active?.methodId ?? null,
          pluginVersion: runtime.plugin.version
        };
      },
      search: async (input) => {
        const query = typeof input.query === "string" ? input.query.trim() : "";
        if (!query) throw new Error("query is required");
        const credential = await runtime.authorization.getCredential("api-key");
        if (!credential?.apiKey) throw new Error("Connect Acme Research before searching");
        const response = await fetch("https://api.acme.example/v1/research/search", {
          method: "POST",
          headers: {
            authorization: `Bearer ${credential.apiKey}`,
            "content-type": "application/json"
          },
          body: JSON.stringify({ query })
        });
        if (!response.ok) throw new Error(`Acme search failed with HTTP ${response.status}`);
        return response.json();
      }
    }
  };
}
export {
  createAcmeService as default
};
